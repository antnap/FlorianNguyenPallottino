/*
 * R_GalloPallottino.h
 *
 *  Created on: 10 dic 2017
 *      Author: antonio
 */

#ifndef PROCEDURE_R_GALLOPALLOTTINO_H_
#define PROCEDURE_R_GALLOPALLOTTINO_H_


void set_N(int *V, int i, int value, int *total) {

	if (value == 1) {
		if (V[i] == 0) {
			V[i] = 1;
			total++;
		}
	} else {
		if (V[i] == 1) {
			V[i] = 0;
			total--;
		}
	}

}

void R_GalloPallottino( GRAPH *G, V_set *Vr, V_set *Vs, int r, int s ) {


	int i, j;

	int totalNT = 0;
	int totalNQ = 0;
	int totalNP = 0;

	NT_t *NT = (NT_t *) malloc(sizeof(NT_t));
	NQ_t *NQ = (NQ_t *) malloc(sizeof(NQ_t));
	NP_t *NP = (NP_t *) malloc(sizeof(NP_t));

	NT->V = (bool *) malloc((G->n + 1) * (sizeof(bool)));
	NQ->V = (bool *) malloc((G->n + 1) * (sizeof(bool)));
	NP->V = (bool *) malloc((G->n + 1) * (sizeof(bool)));

	for (i = 0; i < G->n; ++i) {
		NT->V[i] = false;
		NQ->V[i] = false;
		NP->V[i] = false;
	}

	int STEP = 1;
	int STOP = 0;
	int u = s;

	for ( i = 1; i <= G->n; ++i ) {
		for ( j = 0; j < G->deg_[ i ]; ++j ) {
			int primal_cost = G->FS[ i ][ j ]->w_ij;
			if ( primal_cost > 0 ) {
				int dual_cost = primal_cost + Vr->V[ i ].dist - Vr->V[ j ].dist;
				G->FS[ i ][ j ]->wr_ij = dual_cost;
			}
			else {
				G->FS[ i ][ j ]->wr_ij = INT_MAX;
			}
		}
	}

	while (!STOP) {

		switch (STEP) {

		case 1: {
			Vs->V[s].pred = 0;
			Vs->V[s].dist = 0;
			NP->V[s] = true;
			totalNP++;
			u = s;
			STEP = 2;
			break;
		}

		case 2: {

			list_node *temp = Vs->V[u].adj->L;
			while (temp != NULL) {
				int dual_cost = INT_MAX;
				for ( j = 0; j < G->deg_[ u ]; ++j ) {
					if ( G->FS[ u ][ j ]->j == temp->v ) {
						dual_cost = G->FS[ u ][ j ]->wr_ij;
					}
				}
				int DV = Vs->V[u].dist + dual_cost;

				if (DV < Vs->V[temp->v].dist) {

					Vs->V[temp->v].dist = DV;
					Vs->V[temp->v].pred = u;

					if (DV == Vs->V[u].dist) {

						if (NQ->V[temp->v] == false) {
							NQ->V[temp->v] = true;
							totalNQ++;
						}

						if (NT->V[temp->v] == true) {
							NT->V[temp->v] = false;
							totalNT--;
						}

					}
					else {

						if (NT->V[temp->v] == false) {
							NT->V[temp->v] = true;
							totalNT++;
						}

					}

				}
				temp = temp->next;
			}
			STEP = 3;
			break;
		}

		case 3: {

			if (totalNQ == 0) {

				STEP = 4;
			}
			else {

				for (i = 1; i <= G->n; ++i) {
					if (NQ->V[i] == true) {

						u = i;

						NQ->V[i] = false;
						totalNQ--;

						if (NP->V[i] == false) {
							NP->V[i] = true;
							totalNP++;
						}

						break;

					}
				}
				STEP = 2;
			}
			break;
		}

		case 4: {

			if (totalNT == 0) {

				STEP = 5;

			}
			else {

				int min_value = INT_MAX;
				int min_index = -1;
				for (i = 1; i <= G->n; ++i) {
					if (NT->V[i] == true) {
						if (min_value > Vs->V[i].dist) {
							min_value = Vs->V[i].dist;
							min_index = i;
						}
					}
				}

				u = min_index;

				for (i = 1; i <= G->n; ++i) {
					if (NT->V[i] == true) {
						if (Vs->V[i].dist == min_value) {

							NT->V[i] = false;
							totalNT--;

							if (NQ->V[i] == false) {
								NQ->V[i] = true;
								totalNQ++;
							}
						}
					}
				}
				STEP = 3;
			}
			break;
		}

		case 5: {

			for (i = 1; i <= G->n; ++i) {
				Vs->V[i].dist = Vs->V[i].dist + Vr->V[i].dist - Vr->V[s].dist;
			}
			STOP = 1;
			break;
		}

		}

	}

/*	for (i = 1; i <= G->n; ++i) {
		fprintf(stderr," %d = %d - %d\G->n", i, Vs->V[i].dist, Vs->V[i].pred);
	}*/

	/*

	while (!STOP) {

		switch (STEP) {

		case 1: {

			printf("STEP %d\G->n", STEP);
			getchar();

			Vs->V[s].pred = 0;
			Vs->V[s].dist = 0;
			NP->V[s] = 1;
			totalNP++;
			u = s;
			STEP = 2;
			break;
		}

		case 2: {

			printf("STEP %d\G->n", STEP);
			getchar();

			list_node *temp = Vs->V[u].adj->L;

			fprintf(stderr, "Analyze FS of %d\G->n", u);

			while (temp != NULL) {

				int DV = Vs->V[u].dist + W_prime[u][temp->v];

				fprintf(stderr, "DV(%d) = %d and ds[%d] = %d\G->n",
						temp->v, DV, u, Vs->V[u].dist);

				if (DV < Vs->V[temp->v].dist) {
					Vs->V[temp->v].dist = DV;
					Vs->V[temp->v].pred = u;
				}
				if (DV == Vs->V[u].dist) {

					if (NQ->V[temp->v] == 0) {
						NQ->V[temp->v] = 1;
						totalNQ++;
						fprintf(stderr, "%d inserted in NQ - totalNQ = %d\G->n",
								temp->v, totalNQ);
					}

					if (NT->V[temp->v] == 1) {
						NT->V[temp->v] = 0;
						totalNT--;

						fprintf(stderr, "%d extracted from NT - totalNT = %d\G->n",
								temp->v, totalNT);

					}

				} else {

					if (NT->V[temp->v] == 0) {
						NT->V[temp->v] = 1;
						totalNT++;

						fprintf(stderr, "%d inserted in NT - totalNT = %d\G->n",
								temp->v, totalNT);

					}

				}
				temp = temp->next;
			}
			STEP = 3;
			break;
		}

		case 3: {

			printf("STEP %d\G->n", STEP);
			getchar();

			if (totalNQ == 0) {
				STEP = 4;
			} else {
//				int scanned = 0;
				int newTotalNQ = totalNQ;

				for (i = 1; i <= G->n; ++i) {

					if (NQ->V[i] == 1) {

//						scanned++;

						if (NQ->V[i] == 1) {
							NQ->V[i] = 0;
							newTotalNQ--;

							if (NP->V[i] == 0) {
								NP->V[i] = 1;
								totalNP++;
							}

						}

					}
//					if (scanned == totalNQ)
//						break;

				}
				totalNQ = newTotalNQ;
				STEP = 2;
			}
			break;
		}

		case 4: {

			printf("STEP %d\G->n", STEP);
			getchar();

			if (totalNT == 0) {
				STEP = 5;
			} else {
//				int scanned = 0;
				int min = INT_MAX;

				for (i = 1; i <= G->n; ++i) {
					if (NT->V[i] != 0) {
//						scanned++;
						if (Vs->V[i].dist < min) {
							min = Vs->V[i].dist;
							u = i;
						}
					}
//					if (scanned == totalNT)
//						break;
				}

				fprintf(stderr, "---> min = %d - dist = %d\G->n", u, Vs->V[u].dist);

//				scanned = 0;
				int newTotalNT = totalNT;

				for (i = 1; i <= G->n; ++i) {

					if (NT->V[i] == 1) {
//						scanned++;

						if (Vs->V[i].dist == Vs->V[u].dist && u != i) {

							if (NT->V[i] == 1) {
								NT->V[i] = 0;
								newTotalNT--;

								if (NQ->V[i] == 0) {
									NQ->V[i] = 1;
									totalNQ++;
								}
							}
						}
//						if (scanned == totalNT)
//							break;
					}
				}
				totalNT = newTotalNT;
				STEP = 3;
			}
			break;
		}

		case 5: {
			for (i = 1; i <= G->n; ++i) {
				Vs->V[i].dist = Vs->V[i].dist + Vr->V[i].dist - Vr->V[s].dist;
			}
			STOP = 1;
			break;
		}

		}

	}

	*/

}

#endif /* PROCEDURE_R_GALLOPALLOTTINO_H_ */
