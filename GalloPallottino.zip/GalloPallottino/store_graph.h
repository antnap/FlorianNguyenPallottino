/*
 * store_graph.h
 *
 *  Created on: 23 apr 2016
 *      Author: antonio
 */

#ifndef STORE_GRAPH_H_
#define STORE_GRAPH_H_


int n;                       // vertex Number;
int m;                       // edge   Number;
int **W;                     // weight Matrix;

void stores_graph(char *filename)
{

   /**

      This function, acquires from a file the informations about the graph.
      It stores the vertices number and the edges number that are in the first
      line of the file. Then, reading the other lines it will store the
      Forward Star for each node and the matrix of the weight that will be
      contained in (n x n)-matrix; where n is the cardinality of the vertex-set.

      Input:
            - filename : the string that represents the name of the file;

      Output:
             - m e n   : number of edges and number of vertices of the graph;
             - W       : n x n wheight matrix;
             - adj[v]  : for each v in V, the function build the adiancent list
                         about the vercites that are in the set ForwardStar(v);

   */



   FILE *G=fopen(filename, "r");
   // Open the file for reading

   if (G==NULL)
   {
      // If there are problem to open the file the function exit with an error
      printf("Cannot open the file!!!");
      exit(1);
   }

   fscanf(G, "%d %d", &n, &m);
   // Read and stores the vertex number and weight number

   W=allocateMatrix(n+1, n+1);
   // Invokes a function to allocates bidimensional matrix, where each dimension
   // has n elements. In this case we allocate the weight matrix, W.

   int i=1;

   while (!feof(G))
   {
   // Scanning all the file lines

      int j;

      for (j=1; j<=n; j++)
      {
          int value;
          fscanf(G, "%d", &value);

          /**
           Save the value of each entries.
           In this way we can evaluate if there is or not an edge from th
           vertex i to j and we can determines its weight.
                     ___
                    |
                    |  x > 0, there is the arc (i,j) and its weight is x;
            value = |
                    |  x = 0, there isn't the arc (i,j);
                    |___
          */

          if (value > 0)
          {
             W[i][j] = value;
          }
          else {
        	  W[i][j] = 0;
          }


      }
      fscanf(G, "\n");
      i++;

   }

}

int getVertexNumber()
{
   return n;
}

int getEdgeNumber()
{
   return m;
}

int **getWeightMatrix()
{
   return W;
}

int findAndGetCmax()
{

    /**
       This function find and return the value of the max weight in the graph;
    */

    int i,j;

    int MaxWeight=0;

    for (i=1; i<=n; i++)
    {
       for (j=1; j<=n; j++)
       {
          if (MaxWeight<W[i][j])
          {
             MaxWeight=W[i][j];
          }
       }
    }

    return MaxWeight;

}

#endif /* STORE_GRAPH_H_ */
